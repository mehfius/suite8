function pageMountSecions(json){
  
  var section = document.createElement(json);

      section.style = "background-image:"+json.files+";";

      section.innerHTML = json.content;
  
  return section;
  
}